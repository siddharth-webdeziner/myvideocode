import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { appRouting } from './app.routing.module';
import {FormsModule} from '@angular/forms';


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MyvideosComponent } from './myvideos/myvideos.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MyvideosComponent,
  ],
  imports: [
    BrowserModule,
    appRouting,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
