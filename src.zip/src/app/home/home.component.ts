import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  urlArr:any = [];

  constructor() { }

  ngOnInit() {
    //localStorage.removeItem('urlData');
    if(localStorage.getItem('urlData') != null){
      this.urlArr.push((localStorage.getItem('urlData')));
      console.log("this.urlArr : ",JSON.parse(this.urlArr));
      this.urlArr = JSON.parse(this.urlArr);
    }
    
  }

  onFormSubmit(userForm: NgForm) {
    console.log("Before", this.urlArr," userForm.value :",userForm.value);
    this.urlArr.push(userForm.value);
    console.log("Length", this.urlArr);
    localStorage.setItem("urlData", JSON.stringify(this.urlArr));
    this.resetUserForm(userForm)
  }

  resetUserForm(userForm: NgForm) {
    userForm.resetForm();
  }
 

}
