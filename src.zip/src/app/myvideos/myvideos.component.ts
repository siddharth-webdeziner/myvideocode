import { Component, OnInit } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-myvideos',
  templateUrl: './myvideos.component.html',
  styleUrls: ['./myvideos.component.css']
})
export class MyvideosComponent implements OnInit {
  urlArr:any = [];
  constructor(public sanitizer: DomSanitizer) {
    if(localStorage.getItem('urlData') != null){
      this.urlArr.push((localStorage.getItem('urlData')));
      console.log("this.urlArr : ",JSON.parse(this.urlArr));
      this.urlArr = JSON.parse(this.urlArr);
      this.sanitizer = sanitizer;
    }
  }

  ngOnInit() {
   
  }
  videoURL(item){
    console.log(item);
    return this.sanitizer.bypassSecurityTrustResourceUrl('http://www.youtube.com/embed/'+item);

    
  }

}
