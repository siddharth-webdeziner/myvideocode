import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MyvideosComponent } from './myvideos/myvideos.component';

const appRoutes: Routes = [
  { 
    path: '', 
    component: HomeComponent
  },
  { path: 'myvideos', component: MyvideosComponent },
//   { path: '**', component: NotFoundComponent }
];

export const appRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes);